#INFORMATION


Name: Jubal
Version: alpha
Type: vst plugin
Number of features: 1
Features include: simple eq
State: in development


#SIDE NOTE


Jubal is currently having multiple update, open repo!


